# HERRERÍA CALAVERA Y ANCLA - LOTE 1 FINAL

## Especificaciones de Entrega:
- **Calidad Artística:** Estilo inspirado en la referencia visual principal, con bloques de piedra medievales grandes, juntas texturizadas, paleta gris-beige con matices azulados y remates superiores luminosos.
- **Geometría Estricta 2:1:** Suelos rigurosamente a 128x64 píxeles, sin desbordes ni transparencias erróneas.
- **Pivotes Validados:** Muros y pilares con contacto base exacto en Y=128 (pivote [64,128]).
- **Ausencia de Contaminación:** Transparencia alfa real, sin negros puros (#000000) ni magenta (#ff00ff).
